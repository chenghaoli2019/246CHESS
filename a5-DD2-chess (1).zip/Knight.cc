#include "Knight.h"
// Constructor for the Knight class, initializes the knight piece with its color and position.
Knight::Knight(ChessColor color, Position position) :
        ChessPiece{ChessType::KNIGHT, color, position} {}
// Checks if the knight can move to the specified position on the board.
MoveResult Knight::CanMove(ChessBoard& board, const Move& move) {
    std::vector<ExtendedMove> PotMove = AllMoves(board, true);
    for (auto ExtendedMove : PotMove) {
        if (move.getStart() == ExtendedMove.getStart() && move.getEnd() == ExtendedMove.getEnd()) return {true, false};
    }
    return {false, false};
}
// Returns a vector of available moves for the knight piece on the board.
std::vector<ExtendedMove> Knight::AllMoves(ChessBoard& board, bool check) {
    std::vector<ExtendedMove> moves;
    ChessColor opponentColor = color == ChessColor::WHITE ? ChessColor::BLACK : ChessColor::WHITE;
    for (int x = -2; x<=2; x++){
        int attackbonus;
        double attackscore;
        if (color == ChessColor::BLACK){
                attackbonus = max(0, -x);
                attackscore = attackbonus/3;
            }
        if (color == ChessColor::WHITE){
                attackbonus = max(0, x);
                attackscore = attackbonus/3;
            }
        if (x != 0){
        int absx = std::abs(x);
        int y1 = 3 - absx;
        int y2 = 0 - y1;
        int xaxisyvalue[2] = {y1,y2};
        for (int y:xaxisyvalue){
  
            Position newPosition {curposition.getRow() + x, curposition.getCol() + y};
            if (board.isValidPos(newPosition)) {; // check if newPosition is within the grid
        // check if newPosition is occupied by myself
                if (!board.isPositionOccupiedByColor(newPosition, color)){
                    Move move {curposition, newPosition, this};
                    
                    bool canCheck = check && board.TrialMove(move, opponentColor);
                    int selfworth = check ? board.TrialCapture(move, color).score : 0;
                    double positioningScore = newPosition.getcentervalue() - curposition.getcentervalue();
                    bool canCapture = false;
                    if (!board.isTileEmpty(newPosition)) canCapture = true;
                    ExtendedMove possibleMove {curposition, newPosition, this, canCapture, canCheck,
                                            canCapture ? board.getTileAtPos(newPosition).HavePiece()->HaveScore() : 0,
                                            selfworth, attackscore , positioningScore};//0 is for offensive score
                    if (check) {
                        bool willCheck = board.TrialMove(possibleMove, color);
                        if (!willCheck) {
                            moves.emplace_back(possibleMove);
                        }
                    } else moves.emplace_back(possibleMove);
                }}}}}
    return moves;
}
