#include <iostream>
#include "TextDisplay.h"
#include "Tile.h"

// Constructor: Initializes the display with size+2 to accommodate borders.
TextDisplay::TextDisplay(int size) : display(size+2), size{size} {
    for (int i = 0; i <= size+1; ++i) {
        display[i].resize(size+2); // essentially 10 x 10
        for (int j = 1; j <= size; ++j) {
            display[i][j] = '_'; // Initialize all inner cells with '_'
        }
    }
}

// Returns the display type as Text.
DisplayType TextDisplay::displayType() {
    return DisplayType::Text;
}

// Updates the display when notified of a change in a Tile.
void TextDisplay::notify(Tile &c, bool firstRender) {
    int col = c.getPosition().getCol();
    int row = c.getPosition().getRow();
    
    // Check if there is a chess piece on the tile
    if (c.isOccupied()) {
        ChessPiece* myChessPiece = c.HavePiece();
        char chessChar = ' ';
        ChessType type = myChessPiece->getType();
        ChessColor color = myChessPiece->getColor();

        // Determine the character representation of the chess piece
        if (type == ChessType::PAWN) {
            chessChar = (color == ChessColor::BLACK) ? 'p' : 'P';
        } else if (type == ChessType::ROOK) {
            chessChar = (color == ChessColor::BLACK) ? 'r' : 'R';
        } else if (type == ChessType::BISHOP) {
            chessChar = (color == ChessColor::BLACK) ? 'b' : 'B';
        } else if (type == ChessType::KNIGHT) {
            chessChar = (color == ChessColor::BLACK) ? 'k' : 'K';
        } else if (type == ChessType::QUEEN) {
            chessChar = (color == ChessColor::BLACK) ? 'q' : 'Q';
        } else if (type == ChessType::KING) {
            chessChar = (color == ChessColor::BLACK) ? 'i' : 'I';
        }
        display[row][col] = chessChar;    
    } 
    else {
        display[row][col] = '_'; // Set to empty if no piece is on the tile
    }
}

// Overloads the << operator to print the board.
std::ostream &operator<<(std::ostream &out, const TextDisplay &td) {
    char ch = 'a';
    out << "  ";
    for (int i = 0; i < td.size; ++i) {
        out << ch; // Print column headers (a, b, c, ...)
        ch++;
    }
    out << endl;
    out << endl;

    // Print the board rows
    for (int i = td.size; i > 0; --i) {
        out << i << " "; // Print row number
        for (int j = 1; j <= td.size; ++j) {
            out << td.display[i][j]; // Print the tile (empty or with a chess piece)
        }
        out << " " << i << endl; // Print row number on the other side
    }
    out << endl;

    // Print column headers again
    ch = 'a';
    out << "  ";
    for (int i = 0; i < td.size; ++i) {
        out << ch;
        ch++;
    }
    return out;
}

// Prints the content of the display.
void TextDisplay::printContent() {
    cout << (*this) << endl;
}

// Prints a message to the console.
void TextDisplay::printMessage(string msg) {
    cout << msg << endl;
}

// Destructor for TextDisplay (Yeah, it's here for nothing)
TextDisplay::~TextDisplay() {}
