#include "GraphicsDisplay.h"
#include <iostream>
using namespace std;

// Helper function to map a chess piece on a tile to its string representation.
string mapChessPieceToChar(Tile& tile) {
    if (!tile.isOccupied()) return ""; 
    string piece;
    ChessType type = tile.HavePiece()->getType();    
    // Map the piece type to the corresponding character based on color.
    if (tile.isOccupiedByColor(ChessColor::BLACK)) {
        if (type == ChessType::PAWN) {
            piece = "p";
        } else if (type == ChessType::ROOK) {
            piece = "r";
        } else if (type == ChessType::BISHOP) {
            piece = "b";
        } else if (type == ChessType::KNIGHT) {
            piece = "k";
        } else if (type == ChessType::QUEEN) {
            piece = "q";
        } else if (type == ChessType::KING) {
            piece = "i";
        } 
    } else if (tile.isOccupiedByColor(ChessColor::WHITE)) {
        if (type == ChessType::PAWN) {
            piece = "P";
        } else if (type == ChessType::ROOK) {
            piece = "R";
        } else if (type == ChessType::BISHOP) {
            piece = "B";
        } else if (type == ChessType::KNIGHT) {
            piece = "K";
        } else if (type == ChessType::QUEEN) {
            piece = "Q";
        } else if (type == ChessType::KING) {
            piece = "I";
        } 
    }
    return piece;
} 

// Constructor: Initializes the GraphicsDisplay with the Xwindow and grid size.
GraphicsDisplay::GraphicsDisplay(Xwindow& xw, int gridSize) :
        xw{xw}, size{gridSize + 2} {
    display.resize(size, vector<string>(size, ""));
    drawGrid();
}

// Notify method to update the state of the display when a tile changes.
void GraphicsDisplay::notify(Tile& c, bool firstRender)  {
    int tileSize = window / size;
    int row = size - 1 - c.getPosition().getRow();
    int col = c.getPosition().getCol();
    int x = (col+1) * tileSize;
    int y = (row) * tileSize;
    // Redraw the tile background if not the first render
    if (!firstRender){ 
        int color = row % 2 != col % 2 ? Xwindow::Black : Xwindow::White;
        xw.fillRectangle(x, y, tileSize, tileSize, color);
    } 
    // Draw the chess piece on the tile with appropriate color
    string chessChar = mapChessPieceToChar(c);
    display[row][col] = chessChar;
    if (c.isOccupied()) {
        if (c.isOccupiedByColor(ChessColor::WHITE)) {
            xw.drawString(x + (tileSize / 3), y + (tileSize / 2), chessChar, Xwindow::Red);
        } else xw.drawString(x + (tileSize / 3), y + (tileSize / 2), chessChar, Xwindow::Blue);
    }
}

// void GraphicsDisplay::notify(Tile& c, bool firstRender)  {
//     if (!firstRender){
//         int tileSize = window / size;
//         int row = size - 1 - c.getPosition().getRow();
//         int col = c.getPosition().getCol();
//         int color = row % 2 != col % 2 ? Xwindow::Black : Xwindow::White;
//         int x = (col+1) * tileSize;
//         int y = (row) * tileSize;
//         xw.fillRectangle(x, y, tileSize, tileSize, color);
        
//         string chessChar = mapChessPieceToChar(c);
//         display[row][col] = chessChar;
//         if (c.isOccupied()) {
//             if (c.isOccupiedByColor(ChessColor::WHITE)) {
//                 xw.drawString(x + (tileSize / 3), y + (tileSize / 2), chessChar, Xwindow::Red);
//             } else xw.drawString(x + (tileSize / 3), y + (tileSize / 2), chessChar, Xwindow::Blue);
//         }
//     } else {
//         int tileSize = window / size;
//         int row = size - 1 - c.getPosition().getRow();
//         int col = c.getPosition().getCol();
//         int x = (col+1) * tileSize;
//         int y = (row) * tileSize;
        
//         string chessChar = mapChessPieceToChar(c);
//         display[row][col] = chessChar;
//         if (c.isOccupied()) {
//             if (c.isOccupiedByColor(ChessColor::WHITE)) {
//                 xw.drawString(x + (tileSize / 3), y + (tileSize / 2), chessChar, Xwindow::Red);
//             } else xw.drawString(x + (tileSize / 3), y + (tileSize / 2), chessChar, Xwindow::Blue);
//         }
//         firstRender = false;
//     }

// }

// Draw the initial grid with column letters and row numbers.
void GraphicsDisplay::drawGrid() {
    int tileSize = window / size;
    char letterCol = 'a';
    string letterStr = string(1, letterCol);
    // Draw the column letters on the top.
    for (int i = 2; i < size; i++) {
        xw.drawString(i*tileSize + tileSize/3, tileSize/2, letterStr);
        letterCol += 1;
        letterStr = string(1, letterCol);
    }
    // Draw the rows with alternating colors and row numbers.
    for (int i = 1; i < size - 1; i++) {
        xw.drawString(tileSize, i * tileSize + tileSize/2, to_string(size-i-1));
        for (int j = 2; j < size; j++) {
            if (i % 2 != j % 2) {
                xw.fillRectangle(j*tileSize, i*tileSize, tileSize, tileSize, Xwindow::White);
            } else xw.fillRectangle(j*tileSize, i*tileSize, tileSize, tileSize, Xwindow::Black);
        }
        xw.drawString((size + 1) * tileSize, i * tileSize + tileSize/2, to_string(size-i-1));
    }
    // Draw the column letters on the bottom.
    letterCol = 'a';
    letterStr = string(1, letterCol);
    for (int i = 2; i < size; i++) {
        xw.drawString(i*tileSize + tileSize/3, tileSize * 9 + tileSize/2, letterStr);
        letterCol += 1;
        letterStr = string(1, letterCol);
    }
}
// Returns the display type as Graphical.
DisplayType GraphicsDisplay::displayType() {
    return DisplayType::Graphical;
}

// Destructor for GraphicsDisplay (yes, nothing)
GraphicsDisplay::~GraphicsDisplay() {
}
