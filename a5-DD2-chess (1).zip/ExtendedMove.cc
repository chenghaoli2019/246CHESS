#include "ExtendedMove.h"

// Constructor for the ExtendedMove class, initializes an extended move with various attributes including position, piece, and move characteristics.
ExtendedMove::ExtendedMove(Position start, Position end, ChessPiece* chessPiece, bool AttackingEnemy, bool canCheck,
                      int scoretaken, int selfworth , double offensiveScore, double mapcontrolScore )
 : Move{start, end, chessPiece}, AttackingEnemy{AttackingEnemy}, canCheck{canCheck}, enPassant{false}, Promo{false},
    scoretaken{scoretaken}, selfworth{selfworth} ,offensiveScore{offensiveScore}, mapcontrolScore{mapcontrolScore}  {}

// Overloads the less-than operator to compare two extended moves based on their ability to check and attack.
bool ExtendedMove::operator<(const ExtendedMove& other) const {
    if (canCheck && !other.canCheck) return false;
    if (other.canCheck && !canCheck) return true;
    if (AttackingEnemy && !other.AttackingEnemy) return false;
    if (other.AttackingEnemy && !AttackingEnemy) return true;
    return true;
}


// Marks the move as an en passant move.
void ExtendedMove::isEnPassant() {
    enPassant = true;
}

// Returns whether the move is an en passant move.
bool ExtendedMove::getEnPassant() const {
    return enPassant;
}

// Returns whether the move is a promotion move.
bool ExtendedMove::getPromo() {
    return Promo;
}

// Sets the promotion status of the move.
void ExtendedMove::setPromo(bool p) {
    Promo = p;
}

// Returns whether the move attacks an enemy piece.
bool ExtendedMove::getAttackingEnemy() const {
    return AttackingEnemy;
}

// Returns whether the move can check the opponent's king.
bool ExtendedMove::getCanCheck() const {
    return canCheck;
}

// Returns the score of the piece taken by the move.
int ExtendedMove::getScoretaken() const {
    return scoretaken;
}

// Returns the self-worth score of the move.
int ExtendedMove::getselfworth() const {
    return selfworth;
}

// Returns the offensive score of the move.
double ExtendedMove::getoffensiveScore() const {
    return offensiveScore;
}

// Returns the map control score of the move.
double ExtendedMove::getmapcontrolScore() const {
    return mapcontrolScore;
}
