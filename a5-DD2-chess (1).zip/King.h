#ifndef CHESS_KING_H
#define CHESS_KING_H

#include "ChessPiece.h"
class King : public ChessPiece {
public:
    King(ChessColor color, Position position);
    MoveResult CanMove(ChessBoard& board, const Move& move) override;
    std::vector<ExtendedMove> AllMoves(ChessBoard& board, bool check) override;
    bool isCastlingAvailable(ChessBoard& board, const Position& rookPos);
};


#endif //CHESS_KING_H
