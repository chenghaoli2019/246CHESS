#include "ChessPiece.h"
// Constructor for the ChessPiece class, initializes the chess piece with type, color, position, and total moves.
ChessPiece::ChessPiece(ChessType type, ChessColor color, Position position) :
    type{type}, color{color},curposition{position}, totalMoves{0} {}

// Destructor for the ChessPiece class, responsible for cleanup.
ChessPiece::~ChessPiece() {
}

// Returns the type of the chess piece.
ChessType ChessPiece::getType() const {
    return type;
}

// Returns the color of the chess piece.
ChessColor ChessPiece::getColor() const {
    return color;
}

// Increments the total number of moves made by the chess piece.
void ChessPiece::piecemoved() {
    totalMoves++;
}


// Returns the total number of moves made by the chess piece.
int ChessPiece::getTotalMoves() const {
    return totalMoves;
}


// Overloads the equality operator to compare two chess pieces by their type.
bool operator==(const ChessPiece& a, const ChessPiece& b) {
    return a.getType() == b.getType();
}

// Sets the current position of the chess piece.
void ChessPiece::SetPosition(const Position& position){
    curposition = position;
}


// Returns the score value of the chess piece based on its type.
int ChessPiece::HaveScore() const {
    int val = 0;
    switch (type) {
        case ChessType::KING:
            val = 30;
            break;
        case ChessType::QUEEN:
            val = 20;
            break;
        case ChessType::ROOK:
            val = 10;
            break;
        case ChessType::BISHOP:
            val = 5;
            break;
        case ChessType::KNIGHT:
            val = 5;
            break;
        case ChessType::PAWN:
            val = 3;
            break;
    }
    return val;
}
