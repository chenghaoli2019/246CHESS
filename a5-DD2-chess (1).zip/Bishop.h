#ifndef CHESS_BISHOP_H
#define CHESS_BISHOP_H

#include "ChessPiece.h"

// Class representing a Bishop chess piece, derived from ChessPiece.
class Bishop : public ChessPiece {
    public:
        // Constructor for Bishop, initializing it with color and position.
        Bishop(ChessColor color, Position position);

        // Function to check if the Bishop can make a specified move.
        MoveResult CanMove(ChessBoard& board, const Move& move) override;

        // Function to get all available moves for the Bishop.
        std::vector<ExtendedMove> AllMoves(ChessBoard& board, bool check) override;
};

#endif
