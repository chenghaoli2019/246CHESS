#include "Bishop.h"

// Constructor for Bishop class, initializing it with color and position.
Bishop::Bishop(ChessColor color, Position position) :
    ChessPiece(ChessType::BISHOP, color, position) {}

// Function to check if a move is valid for the Bishop.
MoveResult Bishop::CanMove(ChessBoard& board, const Move& move) {
    // Get all available moves for the Bishop.
    std::vector<ExtendedMove> PotMove = AllMoves(board, false);
    // Check if the given move matches any of the possible moves.
    for (const auto& ExtendedMove : PotMove) {
        if (move.getStart() == ExtendedMove.getStart() && move.getEnd() == ExtendedMove.getEnd()) {
            return {true, false}; // Return true if move is valid.
        }
    }
    return {false, false}; // Return false if move is not valid.
}

// Function to get all available moves for the Bishop.
std::vector<ExtendedMove> Bishop::AllMoves(ChessBoard& board, bool check) {
    std::vector<ExtendedMove> moves;
    const int dimension = board.getDimension();
    ChessColor opponentColor = color == ChessColor::WHITE ? ChessColor::BLACK : ChessColor::WHITE;
    int curRow = curposition.getRow();
    int curCol = curposition.getCol();

    // Diagonal directions for the Bishop's moves.
    // up-right direction
    for (int step = 1; step < dimension; ++step) {
        int newRow = curRow + step;
        int newCol = curCol + step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break; // Break if position is not valid.
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) { // If the tile is occupied.
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) { // If occupied by opponent's piece.
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove); // Add move if valid.
                }
            }
            break; // Stop searching in this direction.
        } else { // If the tile is not occupied.
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove); // Add move if valid.
            }
        }
    }

    // up-left direction
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow + step;
        int newCol = curCol - step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break; // Break if position is not valid.
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) { // If the tile is occupied.
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) { // If occupied by opponent's piece.
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove); // Add move if valid.
                }
            }
            break; // Stop searching in this direction.
        } else { // If the tile is not occupied.
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove); // Add move if valid.
            }
        }
    }

    // down-right direction
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow - step;
        int newCol = curCol + step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break; // Break if position is not valid.
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) { // If the tile is occupied.
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) { // If occupied by opponent's piece.
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove); // Add move if valid.
                }
            }
            break; // Stop searching in this direction.
        } else { // If the tile is not occupied.
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove); // Add move if valid.
            }
        }
    }

    // down-left direction
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow - step;
        int newCol = curCol - step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break; // Break if position is not valid.
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) { // If the tile is occupied.
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) { // If occupied by opponent's piece.
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove); // Add move if valid.
                }
            }
            break; // Stop searching in this direction.
        } else { // If the tile is not occupied.
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove); // Add move if valid.
            }
        }
    }

    return moves;
}
