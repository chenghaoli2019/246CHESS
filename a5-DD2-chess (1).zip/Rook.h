#ifndef CHESS_ROOK_H
#define CHESS_ROOK_H
#include "ChessPiece.h"

class Rook : public ChessPiece {
    public:
        // constructor
        Rook(ChessColor color, Position position);
        // check if input move is valid
        MoveResult CanMove(ChessBoard& board, const Move& move)  override;
        // return all possible moves
        std::vector<ExtendedMove> AllMoves(ChessBoard& board, bool check) override;

};

#endif //CHESS_ROOK_H
