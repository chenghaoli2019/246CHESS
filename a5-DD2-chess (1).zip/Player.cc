#include "Player.h"

// Constructor for the Player class, initializes the player with player number, type, board, and color.
Player::Player(int playerNo, PlayerType playerType, ChessBoard* board, const ChessColor color) :
    playerNo{playerNo}, playerType{playerType}, board{board}, color{color} {}
// Returns the player number.
int Player::getPlayerNo() const {
    return playerNo;
}

// Returns the color of the player.
const ChessColor Player::getColor() const{
    return color;
}

// Destructor for the Player class, responsible for cleanup.
Player::~Player() {}

// Returns the player type.
PlayerType Player::getPlayerType() {
    return playerType;
}




