#ifndef CHESS_GRAPHICSDISPLAY_H
#define CHESS_GRAPHICSDISPLAY_H

#include <vector>
#include "Observer.h"
#include "window.h"
#include "Tile.h"
using namespace std;

class GraphicsDisplay : public Observer {
    Xwindow& xw;
    int size;
    const int window = 500;
    vector<vector<string>> display;
    void drawGrid();
public:
    GraphicsDisplay(Xwindow& xw, int gridSize);
    ~GraphicsDisplay() override;
    void notify(Tile &c, bool firstRender = false) override;
    DisplayType displayType() override;
};

#endif //CHESS_GRAPHICSDISPLAY_H
