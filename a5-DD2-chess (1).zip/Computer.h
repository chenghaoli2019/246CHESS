#ifndef CHESS_Computer_H
#define CHESS_Computer_H


#include "Player.h"

class Computer : public Player {
    int level = 1;
    public:
        Computer(int playerNo, ChessBoard* board, const ChessColor& color);
        void setLevel(int newLevel);
        int getLevel() const;
        int randomIndex(int total);
        ExtendedMove computerMove();
};


#endif //CHESS_Computer_H
