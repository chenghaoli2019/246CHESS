#include "ChessGame.h"

#include "Human.h"
#include "Computer.h"
#include <iostream>
// Constructor for the ChessGame class, initializes the chess board with the given dimension and adds a graphical display.
ChessGame::ChessGame(int dimension, Xwindow& xw) : chessBoard{new ChessBoard{dimension}} {
    cout << *chessBoard << endl;
    chessBoard->addGraphicalDisplay(xw);   
}
// Destructor for the ChessGame class, responsible for cleanup.
ChessGame::~ChessGame() {
}
// Initializes the game with two players, setting their types and levels if they are computer players.
void ChessGame::start(PlayerType pt1, PlayerType pt2, int level1, int level2) {
    if (pt1 == PlayerType::HUMAN) {
        players[0] = std::make_unique<Human>(1, chessBoard.get(), ChessColor::WHITE);
    } else {
        players[0] = std::make_unique<Computer>(1, chessBoard.get(), ChessColor::WHITE);
        auto compPlayer = dynamic_cast<Computer*>(players[0].get());
        if (compPlayer) compPlayer->setLevel(level1);
    }

    if (pt2 == PlayerType::HUMAN) {
        players[1] = std::make_unique<Human>(2, chessBoard.get(), ChessColor::BLACK);
    } else {
        players[1] = std::make_unique<Computer>(2, chessBoard.get(), ChessColor::BLACK);
        auto compPlayer = dynamic_cast<Computer*>(players[1].get());
        if (compPlayer) compPlayer->setLevel(level2);

    }

    inGame = true;
    gameResult = GameResult::IN_PROGRESS;
    isChecked[0] = false;
    isChecked[1] = false;

    chessBoard->getTextDisplay().printMessage("Game begins");
    chessBoard->getTextDisplay().printContent();

    int possibleMoves = 0;
    if (currentTurn == 0) {
        possibleMoves = chessBoard->getExtendedMoves(ChessColor::WHITE, true).size();

    } else {
        possibleMoves = chessBoard->getExtendedMoves(ChessColor::BLACK, true).size();
    }
    if (possibleMoves == 0) {
        inGame = false;
        gameResult = GameResult::DRAW;
        score[0] += 0.5;
        score[1] += 0.5;
    }

    // stalemate setup
    if (getResult() == GameResult::DRAW) {
        chessBoard->getTextDisplay().printMessage("Stalemate");
        init();
    }
}
// Executes a move on the chessboard and handles the result, including checking for checkmate or stalemate.
MoveResult ChessGame::makeMove(const Position& from, const Position& to) {
    Move move {from, to, chessBoard->getTileAtPos(from).HavePiece()};
    MoveResult moveResult = chessBoard->executeMove(move, players[currentTurn]->getColor());

    if (!moveResult.success) return moveResult;
    switchTurn();

    if (chessBoard->isColorInCheck(ChessColor::BLACK)) {
        isChecked[1] = true;
    } else isChecked[1] = false;

    if (chessBoard->isColorInCheck(ChessColor::WHITE)) {
        isChecked[0] = true;
    } else isChecked[0] = false;

    for (int i = 0; i < 2; i++) {
        if (chessBoard->isColorInCheckMate(players[i]->getColor())) {
            inGame = false;
            if (currentTurn == 0) {
                score[1]++;
                gameResult = GameResult::BLACK_WON;
            } else {
                score[0]++;
                gameResult = GameResult::WHITE_WON;
            }
        }
    }
    return moveResult;
}
// Wrapper function for makeMove, which additionally checks for stalemate after a move is made.
MoveResult ChessGame::move(const Position& from, const Position& to) {
    MoveResult res = makeMove(from, to);
    if (inGame && res.success) {
        int possibleMoves = 0;
        if (chessBoard->getTileAtPos(to).isOccupiedByColor(ChessColor::WHITE)) {
            possibleMoves = chessBoard->getExtendedMoves(ChessColor::BLACK, true).size();
        } else {
            possibleMoves = chessBoard->getExtendedMoves(ChessColor::WHITE, true).size();
        }
        if (possibleMoves == 0) {
            inGame = false;
            gameResult = GameResult::DRAW;
            score[0] += 0.5;
            score[1] += 0.5;
        }
    }
    return res;
}

// Checks if the game has started.
bool ChessGame::hasStarted() {
    return inGame;
}
// Handles a player resigning, updating the score and announcing the winner.
void ChessGame::resign() {
    inGame = false;
    if (currentTurn == 0) {
        score[1]++;
        gameResult = GameResult::BLACK_WON;
        chessBoard->getTextDisplay().printMessage("Black wins!");
    } else {
        score[0]++;
        gameResult = GameResult::WHITE_WON;
        chessBoard->getTextDisplay().printMessage("White wins!");
    }

}
// Overloads the output stream operator to display the chess board.
std::ostream &operator<<(std::ostream &out, const ChessGame& game) {
    out << *game.chessBoard;
    return out;
}
// Switches the turn between the two players.
void ChessGame::switchTurn() {
    if (currentTurn < 1) currentTurn++;
    else currentTurn = 0;
}
// Returns a pointer to the array that keeps track of which players are in check.
bool* ChessGame::getIsChecked() {
    return isChecked;
}
// Returns the color of the player whose turn it is.
ChessColor ChessGame::getCurrentColor() {
    return players[currentTurn]->getColor();
}
// Adds a chess piece to the board at the given position.
void ChessGame::addChess(const Position& pos, ChessColor color, ChessType chessType) {
    return chessBoard->placePiece(pos, color, chessType);
}
// Removes a chess piece from the board at the given position.
void ChessGame::removeChess(const Position& pos) {
    return chessBoard->removePiece(pos);
}
// Sets the current turn to the player of the given color.
void ChessGame::setCurrentTurn(ChessColor color) {
    if (color == ChessColor::WHITE) {
        currentTurn = 0;
    } else {
        currentTurn = 1;
    }
}
// Verifies if the current setup on the chess board is valid.
bool ChessGame::verifySetup() {
    return chessBoard->isSetupValid();
}
// Displays the current score of the game.
void ChessGame::displayScore() {
    cout << "Final Score:" << endl;
    cout << "White: " << score[0] << endl;
    cout << "Black: " << score[1] << endl;
}
// Returns the result of the game.
GameResult ChessGame::getResult() {
    return gameResult;
}
// Resets the game to its initial state.
void ChessGame::init() {
    chessBoard->resetBoard();
    setCurrentTurn(ChessColor::WHITE);
    players[0] = nullptr;
    players[1] = nullptr;
}
// Executes an automatic move for a computer player of the given color.
bool ChessGame::autoMove(ChessColor color) {
    MoveResult res;
    if (color == ChessColor::WHITE) {
        if (players[0]->getPlayerType() != PlayerType::COMPUTER) return false;
        Computer* player = dynamic_cast<Computer*>(players[0].get());
   
        ExtendedMove move = player->computerMove();
        res = chessBoard->executeMove(move, color);
        if (res.success && res.pawnPromo) {
            removeChess(move.getEnd());
            addChess(move.getEnd(), ChessColor::WHITE, ChessType::QUEEN);
        }
    } else {
        if (players[1]->getPlayerType() != PlayerType::COMPUTER) return false;
        Computer* player = dynamic_cast<Computer*>(players[1].get());
        ExtendedMove move = player->computerMove();
        res = chessBoard->executeMove(move, color);
        if (res.success && res.pawnPromo) {
            removeChess(move.getEnd());
            addChess(move.getEnd(), ChessColor::BLACK, ChessType::QUEEN);
        }
    }
    if (res.success) {
        if (chessBoard->isColorInCheck(ChessColor::BLACK)) {
            isChecked[1] = true;
        } else isChecked[1] = false;
        if (chessBoard->isColorInCheck(ChessColor::WHITE)) {
            isChecked[0] = true;
        } else isChecked[0] = false;
        switchTurn();

    }
    for (int i = 0; i < 2; i++) {
        if (chessBoard->isColorInCheckMate(players[i]->getColor())) {
            inGame = false;
            if (currentTurn == 0) {
                score[1]++;
                gameResult = GameResult::BLACK_WON;
            } else {
                score[0]++;
                gameResult = GameResult::WHITE_WON;
            }
        }
    }
    return res.success;
}
// Erases all pieces from the chess board.
void ChessGame::erase() {
    for (int row = 1; row <= 8; row++) {
        for (int col = 1; col <= 8; col++) {
            removeChess({row, col});
        }
    }
}
// Promotes a pawn to a specified chess piece type at the given position.
void ChessGame::promotePawn(ChessType chessType, const Position& pos) {
    removeChess(pos);
    if (currentTurn == 0) {
        addChess(pos, ChessColor::BLACK, chessType);
    } else {
        addChess(pos, ChessColor::WHITE, chessType);
    }
    if (chessBoard->isColorInCheck(ChessColor::BLACK)) {
        isChecked[1] = true;
    } else isChecked[1] = false;

    if (chessBoard->isColorInCheck(ChessColor::WHITE)) {
        isChecked[0] = true;
    } else isChecked[0] = false;


    for (int i = 0; i < 2; i++) {
        if (chessBoard->isColorInCheckMate(players[i]->getColor())) {
            inGame = false;
            if (currentTurn == 0) {
                score[1]++;
                gameResult = GameResult::BLACK_WON;
            } else {
                score[0]++;
                gameResult = GameResult::WHITE_WON;
            }
        }
    }
}
// Finalizes the setup of the chessboard, making it ready for gameplay.
void ChessGame::disableCastling() {
    chessBoard->disableCastling();
}
// Displays the current content of the chess board and checks for checkmate or stalemate.
void ChessGame::postMove() {
    chessBoard->getTextDisplay().printContent();
    auto isCheckMate = getIsChecked();
    for (int i = 0; i < 2; i++) {
        if (*(isCheckMate + i)) {
            if (i == 0) {
                chessBoard->getTextDisplay().printMessage("White is in check.");
            } else {
                chessBoard->getTextDisplay().printMessage("Black is in check.");
            }
        }
    }

    // game has ended
    if (!hasStarted()) {
        if (getResult() == GameResult::WHITE_WON) {
            chessBoard->getTextDisplay().printMessage("Checkmate! White wins!");
        } else if (getResult() == GameResult::BLACK_WON) {
            chessBoard->getTextDisplay().printMessage("Checkmate! Black wins!");
        } else {
            chessBoard->getTextDisplay().printMessage("Stalemate");
        }
        init(); 
    }
}
