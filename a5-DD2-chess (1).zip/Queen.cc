#include "Queen.h"
// Constructor for the Queen class, initializes the queen piece with its color and position.
Queen::Queen(ChessColor color, Position position):
    ChessPiece(ChessType::QUEEN, color, position) {}

// Checks if the queen can move to the specified position on the board.
MoveResult Queen::CanMove(ChessBoard& board, const Move& move)  {
    std::vector<ExtendedMove> PotMove = AllMoves(board, true);
    for (const auto ExtendedMove : PotMove) {
        if (move.getStart() == ExtendedMove.getStart() && move.getEnd() == ExtendedMove.getEnd()) return {true, false};
    }
    return {false, false};
}

// Returns a vector of available moves for the queen piece on the board.
std::vector<ExtendedMove> Queen::AllMoves(ChessBoard& board, bool check) {
    std::vector<ExtendedMove> moves;
    const int dimension = board.getDimension();
    ChessColor opponentColor = color == ChessColor::WHITE ? ChessColor::BLACK : ChessColor::WHITE;
    int curRow = curposition.getRow();
    int curCol = curposition.getCol();

    // Add moves to the right
    for (int col = curCol + 1; col <= dimension; ++col) {
        Position newPosition{curRow, col};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves to the left
    for (int col = curCol - 1; col >= 0; --col) {
        Position newPosition{curRow, col};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves upward
    for (int row = curRow + 1; row <= dimension; ++row) {
        Position newPosition{row, curCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves downward
    for (int row = curRow - 1; row >= 0; --row) {
        Position newPosition{row, curCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves to the up-right
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow + step;
        int newCol = curCol + step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves to the up-left
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow + step;
        int newCol = curCol - step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves to the down-right
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow - step;
        int newCol = curCol + step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves to the down-left
    for (int step = 1; step <= dimension; ++step) {
        int newRow = curRow - step;
        int newCol = curCol - step;
        Position newPosition{newRow, newCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (!tile.isOccupiedByColor(color)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth, 0, newPosition.getcentervalue() - curposition.getcentervalue()};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    return moves;
}
