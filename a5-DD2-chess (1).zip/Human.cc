#include "Human.h"

// Constructor for the Human class, initializes the player with player number, board, and color.
Human::Human(int playerNo, ChessBoard *board, const ChessColor &color) :
    Player{playerNo, PlayerType::HUMAN, board, color} {}

