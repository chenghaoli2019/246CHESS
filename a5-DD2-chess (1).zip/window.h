#ifndef CHESS_WINDOW_H
#define CHESS_WINDOW_H
#include <X11/Xlib.h>
#include <iostream>
#include <string>
#include "Observer.h"

class Xwindow {
  Display *d; // Display pointer for X11 display connection
  Window w;   // Window identifier
  int s, width, height; // Default screen and its width and height
  GC gc;      // Graphics context for drawing
  unsigned long colours[5]; // Array of filled colours

 public:
  // Constructor; initializes the window with specified width and height
  Xwindow(int width=600, int height=600);
  // Destructor; closes the display connection and destroys the window
  ~Xwindow();                              

  enum {White=0, Black, Red, Green, Blue}; // Enumeration for available colours

  int getWidth() const;   // width accessor
  int getHeight() const;  // height accessor

  // Draws a filled rectangle at position (x, y)
  void fillRectangle(int x, int y, int width, int height, int colour=Black);

  // Draws a string at position (x, y)
  void drawString(int x, int y, std::string msg, int colour=Black);
};

#endif  // CHESS_WINDOW_H
