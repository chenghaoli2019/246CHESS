#ifndef CHESS_CHESSBOARD_H
#define CHESS_CHESSBOARD_H

#include <vector>
#include <memory>
#include "Tile.h"
#include "TextDisplay.h"
#include "GraphicsDisplay.h"

// Forward declarations of classes and enums
enum class ChessColor;
enum class ChessType;
class Move;
class Position;
class ChessPiece;
class ExtendedMove;
struct MoveResult;
class GraphicsDisplay;

// Structure to store information about captured pieces
struct CapturedInfo {
    bool isCaptured;
    int score;
};

// Class representing a chess board
class ChessBoard {
private:
    int size; // Dimension of the chess board
    std::vector<std::vector<Tile>> grid; // 2D grid representing the board
    TextDisplay displayText; // Text display for the board
    std::unique_ptr<GraphicsDisplay> displayGraphical; // Graphical display for the board
    std::vector<std::unique_ptr<ChessPiece>> pieces; // List of chess pieces on the board

public:
    // Constructor to initialize the board with a given size
    ChessBoard(int size);

    // Destructor for the ChessBoard class
    virtual ~ChessBoard();

    // Function to initialize the board with pieces in their starting positions
    void initializeBoard();

    // Function to verify if a move is valid
    MoveResult verifyMove(const Move& move, ChessColor color);

    // Function to check if a position is valid on the board
    bool isValidPos(const Position& pos) const;

    // Function to simulate a move and check if it results in a check
    bool TrialMove(Move move, ChessColor color);


    // Function to simulate capturing a piece and check if it can be captured back
    CapturedInfo TrialCapture(Move move, ChessColor color);

    // Function to move a chess piece and update its position
    ChessPiece* MovechessPiece(const Position &initial, const Position &final);

    // Function to simulate moving a chess piece (used for checking moves)
    ChessPiece* SimMovechessPiece(const Position &initial, const Position &final);

    // Function to execute a move on the board
    MoveResult executeMove(Move move, ChessColor color);

    // Function to check if a square is empty
    bool isSquareEmpty(const Position& pos) const;

    // Function to check if a square is occupied by a piece of a specific color
    bool isSquareOccupiedByColor(const Position& pos, const ChessColor& color) const;

    // Function to get the tile at a specific position
    const Tile& getTileAtPos(const Position& pos) const;

    // Function to get the dimension of the board
    int getDimension() const;

    // Function to reset the board to its initial state
    void resetBoard();

    // Function to check if a color is in check
    bool isColorInCheck(ChessColor color);

    // Function to check if a color is in checkmate
    bool isColorInCheckMate(ChessColor color);

    // Function to place a piece on the board
    void placePiece(const Position& pos, ChessColor color, ChessType type);

    // Function to remove a piece from the board
    void removePiece(const Position& pos);

    // Function to check if the board setup is valid
    bool isSetupValid();

    // Function to get all possible moves for a specific color
    std::vector<ExtendedMove> getExtendedMoves(ChessColor color, bool check);

    // Function to finalize the setup of the board
    void disableCastling();

    // Function to add a graphical display for the board
    void addGraphicalDisplay(Xwindow& xw);

    // Function to get the text display of the board
    TextDisplay& getTextDisplay();

    // Function to check if a position is empty
    bool isTileEmpty(const Position& pos) const;

    // Function to check if a position is occupied by a piece of a specific color
    bool isPositionOccupiedByColor(const Position& pos, const ChessColor& color) const;

    // Function to simulate an en passant move
    bool simulateEnPassant(Move move, ChessColor color);

     // Overloaded stream insertion operator for outputting the board
    friend std::ostream &operator<<(std::ostream &out, const ChessBoard& board);
};

#endif // CHESS_CHESSBOARD_H
