#ifndef CHESS_KNIGHT_H
#define CHESS_KNIGHT_H
#include "ChessPiece.h"

class Knight : public ChessPiece {
    public:
        Knight(ChessColor color, Position position);
        MoveResult CanMove(ChessBoard& board, const Move& move) override;
        std::vector<ExtendedMove> AllMoves(ChessBoard& board, bool check) override;

};


#endif //CHESS_KNIGHT_H
