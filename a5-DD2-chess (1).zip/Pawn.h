#ifndef CHESS_PAWN_H
#define CHESS_PAWN_H
#include "ChessPiece.h"

class Pawn : public ChessPiece {
    int DeltaY, Delta1x,Delta2x;
    bool EMP;
    bool hasmoved;
    bool checkPromo(const Position& pos);
public:
    Pawn(ChessColor color, Position position);
    MoveResult CanMove(ChessBoard& board, const Move& move) override;
    std::vector<ExtendedMove> AllMoves(ChessBoard& board, bool check) override;
    void EMPSET(bool set);



};


#endif //CHESS_PAWN_H
