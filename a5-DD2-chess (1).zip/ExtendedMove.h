#ifndef CHESS_ExtendedMove_H
#define CHESS_ExtendedMove_H


#include "Move.h"
class ChessPiece;
class ExtendedMove : public Move {
    bool AttackingEnemy;
    bool canCheck;
    bool enPassant;
    bool Promo;
    int scoretaken;
    int selfworth;
    double mapcontrolScore;
    double offensiveScore;
public:
    ExtendedMove(Position start, Position end, ChessPiece* chessPiece, bool AttackingEnemy, bool canCheck,
              int scoretaken, int selfworth, double offensiveScore, double mapcontrolScore);
    bool operator<(const ExtendedMove& other) const;

    void isEnPassant();
    bool getEnPassant() const;
    void setPromo(bool p);
    bool getPromo();
    bool getAttackingEnemy() const;
    bool getCanCheck() const;
    int getScoretaken() const;
    int getselfworth() const;
    double getoffensiveScore() const;
    double getmapcontrolScore() const;
};


#endif //CHESS_ExtendedMove_H
