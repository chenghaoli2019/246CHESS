#include "Tile.h"

// constructor
Tile::Tile(int row, int col) : row{row}, col{col}, occupied{false}, chessPiece{nullptr} {}
Tile::Tile() {}

ChessPiece* Tile::HavePiece() const {
    return chessPiece;
}

Position Tile::getPosition() const {
    Position p = {row, col};
    return p;
}

bool Tile::getOccupied() const{
    return occupied;
}

bool Tile::isOccupied() const {
    return occupied == true;
}

bool Tile::isOccupiedByColor(const ChessColor& color) const {
    if (occupied == false) return false;
    return chessPiece->getColor() == color;
}

void Tile::addChessPiece(ChessPiece* newChessPiece) {
    chessPiece = newChessPiece;
    occupied = true;
}

void Tile::removeChessPiece() {
    chessPiece = nullptr;
    occupied = false;
}

ostream& operator<<(ostream& out, const Tile& tile) {
    return out;
}
