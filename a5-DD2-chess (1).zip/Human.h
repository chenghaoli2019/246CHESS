#ifndef CHESS_Human_H
#define CHESS_Human_H


#include "Player.h"

class Human : public Player {
public:
    Human(int playerNo, ChessBoard* board, const ChessColor& color);
};


#endif //CHESS_Human_H
