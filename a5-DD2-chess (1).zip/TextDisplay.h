#ifndef __TEXTDISPLAY_H__
#define __TEXTDISPLAY_H__
#include <iostream>
#include <string>
#include <vector>
#include "Observer.h"

class TextDisplay: public Observer {
  std::vector<std::vector<char>> display;
  int size;
 public:
  TextDisplay(int size);
  DisplayType displayType() override;
  void notify(Tile &c, bool firstRender = false) override;
  ~TextDisplay() override;
  void printContent();
  void printMessage(std::string msg);
  friend std::ostream &operator<<(std::ostream &out, const TextDisplay &td);
};

#endif
