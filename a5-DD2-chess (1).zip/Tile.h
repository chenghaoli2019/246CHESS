#ifndef CHESS_TILE_H
#define CHESS_TILE_H
#include "ChessPiece.h"
#include <iostream>

// forward declaration
class ChessPiece;
enum class ChessColor;
class Position;

class Tile {
    int row, col;           // row and column position
    bool occupied;          // if the tile is occupied by a piece
    ChessPiece* chessPiece; // point to the piece occupy this tile
public:
    Tile();                             // default constructor
    Tile(int row, int col);             // constructor, initializes at row, col
    ChessPiece* HavePiece() const;  // accessor of chessPiece
    Position getPosition() const;       // accessor of row and col
    bool getOccupied() const;           // accessor of occupied
    bool isOccupied() const;            // check occupied
    bool isOccupiedByColor(const ChessColor& color) const;  // check if occupied by color
    void addChessPiece(ChessPiece* newChessPiece);  // add a piece to tile
    void removeChessPiece();                        // remove a piece from tile
};

// << overload
std::ostream& operator<<(std::ostream& out, const Tile& tile);

#endif //TILE_H
