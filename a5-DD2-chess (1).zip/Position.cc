#include "Position.h"
// Constructor for the Position class, initializes the position with row and column values and calculates the center value.
Position::Position(int row, int col) : row{row}, col{col}, centervalue{0.1 * (9 - col) * (col)} {}


// Returns the row of the position.
int Position::getRow() const {
    return row;
}

// Returns the column of the position.
int Position::getCol() const {
    return col;
}
// Returns the column of the position.
void Position::setRow(int newRow) {
    row = newRow;
}
// Sets the column of the position.
void Position::setCol(int newCol) {
    col = newCol;
}
// Returns the center value of the position.
double Position::getcentervalue(){
    return centervalue;
}
// Overloads the equality operator to compare two positions by their row and column values.
bool operator==(const Position& a, const Position& b) {
    return a.getRow() == b.getRow() && a.getCol() == b.getCol();
}
