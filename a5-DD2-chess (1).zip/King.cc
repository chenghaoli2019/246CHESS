#include "King.h"
// Constructor for the King class, initializes the king piece with its color and position.
King::King(ChessColor color, Position position) :
        ChessPiece{ChessType::KING, color, position} {}

// Checks if the king can move to the specified position on the board.
MoveResult King::CanMove(ChessBoard& board, const Move& move) {
    std::vector<ExtendedMove> PotMove = AllMoves(board, true);
    for (auto ExtendedMove : PotMove) {
        if (move.getStart() == ExtendedMove.getStart() && move.getEnd() == ExtendedMove.getEnd()) return {true, false};
    }
    return {false, false};
}

// Returns a vector of available moves for the king piece on the board.
std::vector<ExtendedMove> King::AllMoves(ChessBoard& board, bool check) {
    std::vector<ExtendedMove> moves;
    for (int x = -1; x<=1; x++){

        for (int y= -1; y<=1; y++)
            if (x!= 0 || y!=0){
                Position newPosition {curposition.getRow() + x, curposition.getCol() + y};
                if (board.isValidPos(newPosition)){ // check if newPosition is within the grid
                    // check if newPosition is occupied by myself
                    if (board.isPositionOccupiedByColor(newPosition, color)) continue;

                    Move move {curposition, newPosition, this};
                    ChessColor opponentColor = color == ChessColor::WHITE ? ChessColor::BLACK : ChessColor::WHITE;
                    bool canCheck = check && board.TrialMove(move, opponentColor);
                    bool canCapture = !board.isTileEmpty(newPosition) && board.isPositionOccupiedByColor(newPosition, color);
                    int capturedScore = canCapture ? board.getTileAtPos(newPosition).HavePiece()->HaveScore() : 0;
                    int selfworth = check ? board.TrialCapture(move, color).score : 0;
                    ExtendedMove possibleMove {curposition, newPosition, this, canCapture, canCheck, capturedScore, selfworth,-2,-2};
                    if (check) {
                        bool willCheck = board.TrialMove(possibleMove, color);
                        if (!willCheck) {
                            moves.emplace_back(possibleMove);

                        }
                    } else {
                        moves.emplace_back(possibleMove);
                    }

            }}

        }
    
    
        
 
    if (totalMoves == 0) {
        int row = curposition.getRow();
        // Positions
        Position rookPos1 = (color == ChessColor::WHITE) ? Position(1, 8) : Position(8, 8);
        Position rookPos2 = (color == ChessColor::WHITE) ? Position(1, 1) : Position(8, 1);

        // Check for Rook
        if (isCastlingAvailable(board,rookPos1)) {
            Position newKingPos(row, curposition.getCol() + 2);  // King's new position
            ExtendedMove possibleMove {curposition, newKingPos, this, false, false, 0, 0,0,20};
            if (check) {
                bool willCheck = board.TrialMove(possibleMove, color);
                if (!willCheck) {
                    moves.emplace_back(possibleMove);
                }
            } else moves.emplace_back(possibleMove);
        }

        
        if (isCastlingAvailable(board,rookPos2)) {
            Position newKingPos(row, curposition.getCol() - 2);  // King's new position
            ExtendedMove possibleMove {curposition, newKingPos, this, false, false, 0, 0 , 0, 20};
            if (check) {
                bool willCheck = board.TrialMove(possibleMove, color);
                if (!willCheck) {
                    moves.emplace_back(possibleMove);
                }
            } else moves.emplace_back(possibleMove);
        }
    }

    return moves;
}
// Checks if castling is available by verifying the rook's position and the path between the king and the rook.
bool King::isCastlingAvailable(ChessBoard& board, const Position& rookPos) {
    ChessPiece* rook = board.getTileAtPos(rookPos).HavePiece();
    if (rook && rook->getTotalMoves() == 0) { //check if rook is not removed
        // Check if spaces between King and Rook are empty
        int startCol = min(curposition.getCol(), rookPos.getCol()) + 1;
        int endCol = max(curposition.getCol(), rookPos.getCol());
        for (int col = startCol; col < endCol; ++col) {
            if (!board.isTileEmpty(Position(curposition.getRow(), col))) {
                return false;
            }
        }
        return true; // All conditions met
    }
    return false; // Rook has moved or does not exist
}
