#include <iostream>
#include <set>
#include <stdexcept>
#include "ChessGame.h"
#include "Position.h"

using namespace std;

enum class Command {
    RESIGN,
    MOVE,
    GAME,
    SETUP,
    INVALID
};

// Convert command string to Command enum
Command strToCommand(const string &command);

// Convert player type string to PlayerType enum
PlayerType strToPlayerType(const string &type);

Command strToCommand(const string &command) {
    if (command == "resign") return Command::RESIGN;
    if (command == "move") return Command::MOVE;
    if (command == "game") return Command::GAME;
    if (command == "setup") return Command::SETUP;
    return Command::INVALID;
}

PlayerType strToPlayerType(const string &type) {
    if (type == "human") return PlayerType::HUMAN;
    if (type.find("computer") != string::npos) return PlayerType::COMPUTER;
    throw logic_error("Invalid Player Type");
}

Position strToPos(string str) {
    if (str.length() != 2 || str[0] < 'a' || str[0] > 'h' || str[1] < '1' || str[1] > '8') {
        throw logic_error("Invalid Position Format");
    }
    char a = str[0];
    char b = str[1];
    int row = b - '0';
    int col = a - 'a' + 1;
    return {row, col};
}

ChessColor strToColor(string str) {
    if ('a' <= str[0] && str[0] <= 'z') {
        return ChessColor::BLACK;
    }
    return ChessColor::WHITE;
}

ChessType strToType(string str) {
    if (str.empty()) {
        throw logic_error("Invalid Chess Type");
    }

    ChessType type;
    switch (str[0]) {
        case 'I': case 'i':
            type = ChessType::KING;
            break;
        case 'Q': case 'q':
            type = ChessType::QUEEN;
            break;
        case 'B': case 'b':
            type = ChessType::BISHOP;
            break;
        case 'K': case 'k':
            type = ChessType::KNIGHT;
            break;
        case 'R': case 'r':
            type = ChessType::ROOK;
            break;
        case 'P': case 'p':
            type = ChessType::PAWN;
            break;
        default:
            throw logic_error("Invalid Chess Type");
    }
    return type;
}

int main() {
    Xwindow xw {};
    string primaryCommand, setupCommand;
    ChessGame game {8, xw};
    PlayerType pt1;
    PlayerType pt2;

    while (cin >> primaryCommand) {
        Command command = strToCommand(primaryCommand);

        switch (command) {
            case Command::GAME:
                if (!game.hasStarted()) {
                    string playerOneType, playerTwoType;
                    int level1 = 1, level2 = 1;
                    cin >> playerOneType >> playerTwoType;

                    pt1 = strToPlayerType(playerOneType);
                    if (pt1 == PlayerType::COMPUTER) level1 = playerOneType[8] - '0';

                    pt2 = strToPlayerType(playerTwoType);
                    if (pt2 == PlayerType::COMPUTER) level2 = playerTwoType[8] - '0';

                    game.start(pt1, pt2, level1, level2);
                } else {
                    cout << "Invalid Command" << endl;
                }
                break;

            case Command::RESIGN:
                if (game.hasStarted()) {
                    game.resign();
                    game.init();
                } else {
                    cout << "Invalid Command" << endl;
                }
                break;

            case Command::MOVE:
                if (game.hasStarted()) {
                    if ((game.getCurrentColor() == ChessColor::WHITE && pt1 == PlayerType::COMPUTER) ||
                        (game.getCurrentColor() == ChessColor::BLACK && pt2 == PlayerType::COMPUTER)) {
                        game.autoMove(game.getCurrentColor());
                    } else {
                        try {
                            string start, end;
                            cin >> start >> end;
                            Position startPos = strToPos(start);
                            Position endPos = strToPos(end);
                            MoveResult result = game.move(startPos, endPos);

                            if (result.pawnPromo) {
                                bool validInput = false;
                                char promotedChess;
                                ChessType newChess;
                                cout << "Congrats! You Can Now Promote Your Pawn to\nQueen (Q/q), Rook (R/r), Bishop (B/b), or Knight (K/k)!\nEnter Your Choice:" << endl;
                                while (!validInput) {
                                    cin >> promotedChess;
                                    switch (promotedChess) {
                                        case 'Q': case 'q':
                                            newChess = ChessType::QUEEN;
                                            validInput = true;
                                            break;
                                        case 'R': case 'r':
                                            newChess = ChessType::ROOK;
                                            validInput = true;
                                            break;
                                        case 'B': case 'b':
                                            newChess = ChessType::BISHOP;
                                            validInput = true;
                                            break;
                                        case 'K': case 'k':
                                            newChess = ChessType::KNIGHT;
                                            validInput = true;
                                            break;
                                        default:
                                            cout << "Invalid Chess Type. Choose from Queen, Rook, Bishop, or Knight" << endl;
                                            cin.clear();
                                            cin.ignore(100, '\n');
                                    }
                                }
                                game.promotePawn(newChess, endPos);
                            }
                            if (!result.success) {
                                cout << "Invalid Move" << endl;
                                continue;
                            }
                        } catch (const logic_error& e) {
                            cout << "Error: " << e.what() << endl;
                            continue;
                        }
                    }
                    game.postMove();
                    cin.ignore();
                    cin.clear();
                } else {
                    cout << "Invalid Command" << endl;
                }
                break;

            case Command::SETUP:
                if (!game.hasStarted()) {
                    bool setUpMode = true;
                    while (setUpMode) {
                        cin >> setupCommand;
                        if (setupCommand == "+") {
                            string type, position;
                            cin >> type >> position;
                            try {
                                ChessType chessType = strToType(type);
                                Position pos = strToPos(position);
                                game.addChess(pos, strToColor(type), chessType);
                                cout << game << endl;
                            } catch (const logic_error& e) {
                                cout << "Error: " << e.what() << endl;
                                continue;
                            }
                        } else if (setupCommand == "-") {
                            string position;
                            cin >> position;
                            try {
                                game.removeChess(strToPos(position));
                                cout << game << endl;
                            } catch (const logic_error& e) {
                                cout << "Error: " << e.what() << endl;
                                continue;
                            }
                        } else if (setupCommand == "=") {
                            string color;
                            cin >> color;
                            ChessColor c = (color == "white") ? ChessColor::WHITE : ChessColor::BLACK;
                            game.setCurrentTurn(c);
                        } else if (setupCommand == "done") {
                            bool isValid = game.verifySetup();
                            if (isValid) {
                                setUpMode = false;
                                cout << "Setup is Completed" << endl;
                                game.disableCastling();
                            } else {
                                cout << "Setup is Not Valid. Please Check the Rules." << endl;
                            }
                        } else if (setupCommand == "erase") {
                            game.erase();
                            cout << game << endl;
                        } else {
                            cout << "Invalid Command" << endl;
                            cin.ignore();
                            cin.clear();
                        }
                    }
                } else {
                    cout << "Invalid Command, You are in A Game ALREADY." << endl;
                }
                break;

            default:
                cout << "Invalid Command" << endl;
                cin.ignore(100, '\n');
                cin.clear();
                break;
        }
    }
    game.displayScore();
}
