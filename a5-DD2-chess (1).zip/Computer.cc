#include "Computer.h"
#include "ExtendedMove.h"
#include <random>
#include <vector>
#include <algorithm>

// Constructor for the Computer class, initializes the player with player number, board, and color.
Computer::Computer(int playerNo, ChessBoard *board, const ChessColor &color) :
    Player{playerNo, PlayerType::COMPUTER, board, color} {}

// Sets the level of the computer player if the level is within the valid range (1 to 4).
void Computer::setLevel(int newLevel) {
    if (newLevel <= 4 && newLevel >= 1) level = newLevel;    
}    

// Returns the current level of the computer player.
int Computer::getLevel() const {
    return level;
}

// Generates a random index within the range of total moves.
int Computer::randomIndex(int total) {
    std::random_device random;
    std::mt19937 eng(random());
    std::uniform_int_distribution<> distr(0, total);
    int randomIndex = distr(eng);
    return randomIndex;
}

// Determines the best move for the computer player based on the current level and returns the move.
ExtendedMove Computer::computerMove() {
    vector<ExtendedMove> moves = board->getExtendedMoves(color, true);
   

    switch (level) {
    case 2: {
            ExtendedMove bestMove = moves[0];

        for (const auto& move : moves) {
            if (move.getCanCheck() > bestMove.getCanCheck()) {
                bestMove = move;
            } else if (move.getCanCheck() == bestMove.getCanCheck() && move.getAttackingEnemy() > bestMove.getAttackingEnemy()) {
                bestMove = move;
            }
        }

        return bestMove;
    }

    case 3: {
        ExtendedMove bestMove = moves[0];

        for (const auto& move : moves) {
            if (move.getselfworth() > bestMove.getselfworth()) {
                bestMove = move;
            } else if (move.getselfworth() == bestMove.getselfworth()) {
                if (move.getCanCheck() > bestMove.getCanCheck()) {
                    bestMove = move;
                } else if (move.getCanCheck() == bestMove.getCanCheck() && move.getAttackingEnemy() > bestMove.getAttackingEnemy()) {
                    bestMove = move;
                }
            }
        }

        // If no move results in a capture or check, choose a random move
        if (!bestMove.getAttackingEnemy() && !bestMove.getCanCheck()) {
            int index = randomIndex(moves.size() - 1);
            return moves[index];
        }

        return bestMove;
    }

    case 4: {
        ExtendedMove bestMove = moves[0]; // Initialize with the first move
        double maxScore = 0;
        bool hasMaxScore = false; // Flag to check if we have set the max score

        for (int i = 0; i < moves.size(); ++i) {
            double curScore = 0;
            if (moves[i].getCanCheck()) curScore += 10; // Add 10 if the move can check
            curScore -= std::abs(10 * moves[i].getselfworth()); // Subtract the absolute value of 40 times the selfworth
            curScore += 10 * moves[i].getScoretaken(); // Add 10 times the scoretaken
            curScore += moves[i].getmapcontrolScore(); // Add the map control score
            curScore += 3 * moves[i].getoffensiveScore(); // Add the offensive score
            

            if (!hasMaxScore || curScore > maxScore) {
                maxScore = curScore;
                bestMove = moves[i];
                hasMaxScore = true; // We have set the max score
            }
        }

        return bestMove; // Return the move with the highest score
            }

    default: {
        int index = randomIndex(moves.size() - 1);
        return moves[index];
    }
    }
}
