#include "Move.h"

// Constructor for the Move class, initializes a move with start and end positions and the chess piece.
Move::Move(Position start, Position end, ChessPiece* chessPiece) :
    start{start},end{end}, chessPiece{chessPiece} {}

// Returns the start position of the move.
const Position& Move::getStart() const{
    return start;
}

// Returns the end position of the move.
const Position& Move::getEnd() const{
    return end;
}

// Returns the chess piece involved in the move.
ChessPiece* Move::HavePiece() {
    return chessPiece;
}
