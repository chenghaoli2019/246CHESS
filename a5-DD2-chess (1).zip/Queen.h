#ifndef CHESS_QUEEN_H
#define CHESS_QUEEN_H
#include "ChessPiece.h"

class Queen : public ChessPiece {
    bool block = false;
   
    public:
        Queen(ChessColor color, Position position);
        MoveResult CanMove(ChessBoard& board, const Move& move) override;
        std::vector<ExtendedMove> AllMoves(ChessBoard& board, bool check) override;

};


#endif //CHESS_QUEEN_H

