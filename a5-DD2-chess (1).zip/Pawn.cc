#include "Pawn.h"
// Constructor for the Pawn class, initializes the pawn piece with its color and position.
Pawn::Pawn(ChessColor color, Position position) :
        ChessPiece{ChessType::PAWN, color, position}, EMP{false} {
    DeltaY = (color == ChessColor::WHITE) ? 1 : -1;
    Delta1x = -1;
    Delta2x = 1;
}
// Checks if the pawn can move to the specified position on the board.
MoveResult Pawn::CanMove(ChessBoard& board, const Move& move) {
    std::vector<ExtendedMove> listoftrials = AllMoves(board, true);
    for (ExtendedMove& trial : listoftrials) {
        if (move.getStart() == trial.getStart() && move.getEnd() == trial.getEnd()) {
            return {true, trial.getPromo()};
        }
    }
    return {false, false};
}
// Returns a vector of available moves for the pawn piece on the board.
std::vector<ExtendedMove> Pawn::AllMoves(ChessBoard& board, bool check) {
    std::vector<ExtendedMove> moves;
    ChessColor opponentColor = (color == ChessColor::WHITE) ? ChessColor::BLACK : ChessColor::WHITE;

    // Normal Move
    Position newPosition{curposition.getRow() + DeltaY, curposition.getCol()};
    if (board.isValidPos(newPosition) && board.isTileEmpty(newPosition)) {
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;
        ExtendedMove possibleMove{curposition, newPosition, this, false, canCheck, 0, selfworth, 0.1 ,0};
        if (checkPromo(newPosition)) possibleMove.setPromo(true);
        if (!check || !board.TrialMove(possibleMove, color)) {
            moves.emplace_back(possibleMove);
        }
    }

    // First Step can choose to go 2 tiles
    if (totalMoves == 0) {
        Position newPosition2{curposition.getRow() + DeltaY * 2, curposition.getCol()};
        if (board.isValidPos(newPosition2) && board.isTileEmpty(newPosition) && board.isTileEmpty(newPosition2)) {
            Move move{curposition, newPosition2, this};
            bool canCheck = check && board.TrialMove(move, opponentColor);
            int selfworth = check ? board.TrialCapture(move, color).score : 0;
            ExtendedMove possibleMove{curposition, newPosition2, this, false, canCheck, 0, selfworth, 0.15,0};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Capture
    Position capture1{curposition.getRow() + DeltaY, curposition.getCol() + Delta1x};
    int cp1positioningScore = capture1.getcentervalue() - curposition.getcentervalue();
    if (board.isValidPos(capture1) && board.isPositionOccupiedByColor(capture1, opponentColor)) {
        Move move{curposition, capture1, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;
        ExtendedMove possibleMove{curposition, capture1, this, true, canCheck, board.getTileAtPos(capture1).HavePiece()->HaveScore(), selfworth, 3 , 0};
        if (checkPromo(capture1)) possibleMove.setPromo(true);
        if (!check || !board.TrialMove(possibleMove, color)) {
            moves.emplace_back(possibleMove);
        }
    }

  
    Position capture2{curposition.getRow() + DeltaY, curposition.getCol() + Delta2x};
    int cp2positioningScore = capture1.getcentervalue() - curposition.getcentervalue();
    if (board.isValidPos(capture2) && board.isPositionOccupiedByColor(capture2, opponentColor)) {
        Move move{curposition, capture2, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;
        ExtendedMove possibleMove{curposition, capture2, this, true, canCheck, board.getTileAtPos(capture2).HavePiece()->HaveScore(), selfworth, 3, 0};
        if (checkPromo(capture2)) possibleMove.setPromo(true);
        if (!check || !board.TrialMove(possibleMove, color)) {
            moves.emplace_back(possibleMove);
        }
    }

    // EMPassant
    for (int colOffset : {-1, 1}) {
        Position pos{curposition.getRow(), curposition.getCol() + colOffset};
        if (board.isValidPos(pos) && board.isPositionOccupiedByColor(pos, opponentColor)) {
            ChessPiece* cp = board.getTileAtPos(pos).HavePiece();
            if (cp->getType() == ChessType::PAWN) {
                Pawn* pawn = dynamic_cast<Pawn*>(cp);
                if (pawn && pawn->EMP) {
                    Position targetPos{curposition.getRow() + DeltaY, curposition.getCol() + colOffset};
                    Move move{curposition, targetPos, this};
                    bool canCheck = check && board.TrialMove(move, opponentColor);
                    int selfworth = check ? board.TrialCapture(move, color).score : 0;
                    ExtendedMove possibleMove{curposition, targetPos, this, true, canCheck, cp->HaveScore(), selfworth ,3 ,0};
                    if (!check || !board.TrialMove(possibleMove, color)) {
                        moves.emplace_back(possibleMove);
                    }
                }
            }
        }
    }

    return moves;
}
// Checks if the pawn should be promoted based on its position.
bool Pawn::checkPromo(const Position& pos) {
    return (pos.getRow() == 8 && color == ChessColor::WHITE) || (pos.getRow() == 1 && color == ChessColor::BLACK);
}


// Sets the en passant status of the pawn.
void Pawn::EMPSET(bool set) {
    EMP = set;
}
