#ifndef CHESS_Observer_H
#define CHESS_Observer_H

class Tile;
enum class DisplayType {Text, Graphical};

class Observer {
    public:
        virtual ~Observer() = default;
        virtual void notify(Tile &c, bool firstRender = false) = 0;
        virtual DisplayType displayType() = 0;
};

#endif
