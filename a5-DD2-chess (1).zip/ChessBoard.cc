#include "ChessBoard.h"
#include "ChessPiece.h"
#include "Pawn.h"
#include "Rook.h"
#include "Knight.h"
#include "Bishop.h"
#include "Queen.h"
#include "King.h"

// Constructor for the ChessBoard class, initializes the board with given size and sets up the display.
ChessBoard::ChessBoard(int size) : size{size}, grid(size + 1, std::vector<Tile>(size + 1)), displayText{size}, displayGraphical{nullptr} {
    initializeBoard(); // Initialize the board with pieces.
}

// Function to initialize the chessboard with pieces in their starting positions.
void ChessBoard::initializeBoard() {
    // Clear the board by removing all pieces and resetting tiles.
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            removePiece({row, col}); // Remove any existing piece at the position.
            grid[row][col] = {row, col}; // Initialize the tile.
        }
    }
    pieces.clear(); // Clear the list of pieces.

    // Place black pieces in their starting positions.
    placePiece({8, 1}, ChessColor::BLACK, ChessType::ROOK);
    placePiece({8, 2}, ChessColor::BLACK, ChessType::KNIGHT);
    placePiece({8, 3}, ChessColor::BLACK, ChessType::BISHOP);
    placePiece({8, 4}, ChessColor::BLACK, ChessType::QUEEN);
    placePiece({8, 5}, ChessColor::BLACK, ChessType::KING);
    placePiece({8, 6}, ChessColor::BLACK, ChessType::BISHOP);
    placePiece({8, 7}, ChessColor::BLACK, ChessType::KNIGHT);
    placePiece({8, 8}, ChessColor::BLACK, ChessType::ROOK);
    
    // Place black and white pawns.
    for (int col = 1; col <= size; col++) {
        placePiece({7, col}, ChessColor::BLACK, ChessType::PAWN);
        placePiece({2, col}, ChessColor::WHITE, ChessType::PAWN);
    }

    // Place white pieces in their starting positions.
    placePiece({1, 1}, ChessColor::WHITE, ChessType::ROOK);
    placePiece({1, 2}, ChessColor::WHITE, ChessType::KNIGHT);
    placePiece({1, 3}, ChessColor::WHITE, ChessType::BISHOP);
    placePiece({1, 4}, ChessColor::WHITE, ChessType::QUEEN);
    placePiece({1, 5}, ChessColor::WHITE, ChessType::KING);
    placePiece({1, 6}, ChessColor::WHITE, ChessType::BISHOP);
    placePiece({1, 7}, ChessColor::WHITE, ChessType::KNIGHT);
    placePiece({1, 8}, ChessColor::WHITE, ChessType::ROOK);
}

// Function to remove a piece from a given position on the board.
void ChessBoard::removePiece(const Position& pos) {
    grid[pos.getRow()][pos.getCol()].removeChessPiece(); // Remove the piece from the tile.
    displayText.notify(grid[pos.getRow()][pos.getCol()]); // Notify the text display of the change.
    if (displayGraphical) {
        displayGraphical->notify(grid[pos.getRow()][pos.getCol()]); // Notify the graphical display if it exists.
    }
}

// Function to get the tile at a specific position.
const Tile& ChessBoard::getTileAtPos(const Position& pos) const {
    return grid[pos.getRow()][pos.getCol()]; // Return the tile at the specified position.
}

// Function to check if a square is empty.
bool ChessBoard::isSquareEmpty(const Position& pos) const {
    return !grid[pos.getRow()][pos.getCol()].isOccupied(); // Return true if the tile is not occupied by any piece.
}

// Function to check if a square is occupied by a piece of a specific color.
bool ChessBoard::isSquareOccupiedByColor(const Position& pos, const ChessColor& color) const {
    return grid[pos.getRow()][pos.getCol()].isOccupiedByColor(color); // Return true if the tile is occupied by a piece of the specified color.
}

// Function to get the dimension of the board.
int ChessBoard::getDimension() const {
    return size; // Return the size of the board.
}

// Function to add a graphical display for the board.
void ChessBoard::addGraphicalDisplay(Xwindow& xw) {
    bool firstRender = true;
    displayGraphical = std::make_unique<GraphicsDisplay>(xw, size); // Create a new graphical display.
    for (int row = size; row > 0; --row) {
        for (int col = 1; col <= size; ++col) {
            displayGraphical->notify(grid[row][col], firstRender); // Notify the graphical display for each tile.
        }
    }
}

// Destructor for the ChessBoard class.
ChessBoard::~ChessBoard() {
}

// Overloaded stream insertion operator for outputting the board to a stream.
std::ostream &operator<<(std::ostream &out, const ChessBoard& board) {
    out << board.displayText; // Output the text display of the board.
    return out;
}

// Function to finalize the setup of the board.
void ChessBoard::disableCastling() {
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            if (grid[row][col].isOccupied() && grid[row][col].HavePiece()->getType() == ChessType::KING) {
                grid[row][col].HavePiece()->piecemoved(); // Increment the total moves of each piece.
            }
        }
    }
}

// Function to get the text display of the board.
TextDisplay& ChessBoard::getTextDisplay() {
    return displayText; // Return the text display.
}

// Function to simulate moving a chess piece (used for checking moves).
ChessPiece* ChessBoard::SimMovechessPiece(const Position &initial, const Position &final) {
    int rowinit = initial.getRow();
    int colinit = initial.getCol();
    auto *tobemoved = grid[rowinit][colinit].HavePiece(); // Get the piece to be moved.
    tobemoved->SetPosition(final); // Set the new position for the piece.
    return tobemoved; // Return the moved piece.
}

// Function to move a chess piece and update its position.
ChessPiece* ChessBoard::MovechessPiece(const Position &initial, const Position &final) {
    int rowinit = initial.getRow();
    int colinit = initial.getCol();
    auto *tobemoved = grid[rowinit][colinit].HavePiece(); // Get the piece to be moved.
    tobemoved->SetPosition(final); // Set the new position for the piece.
    tobemoved->piecemoved(); // Increment the total moves of the piece.
    return tobemoved; // Return the moved piece.
}

// Function to execute a move on the board.
MoveResult ChessBoard::executeMove(Move move, ChessColor color) {
    MoveResult result = verifyMove(move, color); // Verify if the move is valid.
    if (!result.success) return result; // If the move is not valid, return the result.

    // Handle capture of a piece.
    ChessPiece* capturedPiece = grid[move.getEnd().getRow()][move.getEnd().getCol()].HavePiece();
    if (capturedPiece) {
        removePiece(move.getEnd()); // Remove the captured piece.
    }

    // Handle castling move.
    if (move.HavePiece()->getType() == ChessType::KING && std::abs(move.getStart().getCol() - move.getEnd().getCol()) == 2) {
        Position kingStart = move.getStart();
        Position kingEnd = move.getEnd();
        bool kingSide = kingEnd.getCol() > kingStart.getCol(); // Determine if it's king-side or queen-side castling.
        int rookStartCol = kingSide ? 8 : 1; // Set the rook's starting column.
        int rookEndCol = kingSide ? kingEnd.getCol() - 1 : kingEnd.getCol() + 1; // Set the rook's ending column.
        Position rookStart(kingStart.getRow(), rookStartCol);
        Position rookEnd(kingStart.getRow(), rookEndCol);
        ChessPiece* movethispiece = MovechessPiece(rookStart, rookEnd); // Move the rook.
        grid[rookEnd.getRow()][rookEnd.getCol()].addChessPiece(movethispiece); // Add the rook to the new position.
        removePiece(rookStart); // Remove the rook from the old position.
        
        displayText.notify(grid[rookStart.getRow()][rookStart.getCol()]); // Notify the text display.
        displayText.notify(grid[rookEnd.getRow()][rookEnd.getCol()]); // Notify the text display.
        if (displayGraphical) {
            displayGraphical->notify(grid[rookStart.getRow()][rookStart.getCol()]); // Notify the graphical display.
            displayGraphical->notify(grid[rookEnd.getRow()][rookEnd.getCol()]); // Notify the graphical display.
        }
    }

    // Handle en passant move for pawns.
    if (move.HavePiece()->getType() == ChessType::PAWN) {
        if ((move.getStart().getRow() == 7 && move.getEnd().getRow() == 5) || (move.getStart().getRow() == 2 && move.getEnd().getRow() == 4)) {
            Pawn* pawn = dynamic_cast<Pawn*>(move.HavePiece());
            pawn->EMPSET(true); // Set the en passant status for the pawn.
        }
    }

    // Reset en passant status for all pawns.
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            if (!isSquareEmpty({row, col})) {
                auto current = grid[row][col].HavePiece();
                if (current != move.HavePiece() && current->getType() == ChessType::PAWN) {
                    Pawn* currentPawn = dynamic_cast<Pawn*>(current);
                    currentPawn->EMPSET(false); // Reset the en passant status for the pawn.
                }
            }
        }
    }

    // Handle en passant capture.
    if (move.HavePiece()->getType() == ChessType::PAWN && move.getEnd().getCol() != move.getStart().getCol() && !capturedPiece) {
        removePiece({move.getStart().getRow(), move.getEnd().getCol()}); // Remove the captured pawn.
    }

    // Move the piece and update the board.
    ChessPiece* tobemoved = MovechessPiece(move.getStart(), move.getEnd());
    grid[move.getEnd().getRow()][move.getEnd().getCol()].addChessPiece(tobemoved); // Add the piece to the new position.
    removePiece(move.getStart()); // Remove the piece from the old position.

    displayText.notify(grid[move.getStart().getRow()][move.getStart().getCol()]); // Notify the text display.
    displayText.notify(grid[move.getEnd().getRow()][move.getEnd().getCol()]); // Notify the text display.
    if (displayGraphical) {
        displayGraphical->notify(grid[move.getStart().getRow()][move.getStart().getCol()]); // Notify the graphical display.
        displayGraphical->notify(grid[move.getEnd().getRow()][move.getEnd().getCol()]); // Notify the graphical display.
    }

    move.HavePiece()->piecemoved(); // Increment the total moves of the piece.
    return result; // Return the result of the move.
}

// Function to verify if a move is valid.
MoveResult ChessBoard::verifyMove(const Move& move, ChessColor color) {
    if (!isValidPos(move.getStart()) || !isValidPos(move.getEnd())) return {false, false}; // Check if the positions are valid.
    const Tile& tile = grid[move.getStart().getRow()][move.getStart().getCol()];
    if (!tile.isOccupiedByColor(color)) return {false, false}; // Check if the tile is occupied by a piece of the specified color.
    ChessPiece* chessPiece = tile.HavePiece();
    return chessPiece->CanMove(*this, move); // Check if the piece can make the move.
}

// Function to check if a position is valid on the board.
bool ChessBoard::isValidPos(const Position& pos) const {
    return pos.getRow() >= 1 && pos.getRow() <= size && pos.getCol() >= 1 && pos.getCol() <= size; // Return true if the position is within the board boundaries.
}

// Function to reset the board to its initial state.
void ChessBoard::resetBoard() {
    initializeBoard(); // Re-initialize the board.
}

// Function to check if a color is in check.
bool ChessBoard::isColorInCheck(ChessColor color) {
    ChessPiece* king = nullptr;
    int kingRow = 0;
    int kingCol = 0;

    // Find the king's position.
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            if (grid[row][col].getOccupied() == false) continue;
            if (grid[row][col].HavePiece()->getType() == ChessType::KING && grid[row][col].HavePiece()->getColor() == color) {
                king = grid[row][col].HavePiece(); // Find the king piece.
                kingRow = row; // Store the king's row.
                kingCol = col; // Store the king's column.
            }
        }
    }
    if (!king) return false; // If no king is found, return false.

    // Check if any opponent piece can attack the king.
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            if (grid[row][col].getOccupied() == false) continue;
            ChessPiece* chessPiece = grid[row][col].HavePiece();
            if (chessPiece && chessPiece->getColor() != color) {
                Position pos {row, col};
                auto opponentMoves = chessPiece->AllMoves(*this, false);
                for (auto move : opponentMoves) {
                    if (move.getEnd().getRow() == kingRow && move.getEnd().getCol() == kingCol) return true; // Return true if the king can be attacked.
                }
            }
        }
    }
    return false; // Return false if the king is not in check.
}

// Function to check if a color is in checkmate.
bool ChessBoard::isColorInCheckMate(ChessColor color) {
    std::vector<ExtendedMove> possibleMoves = getExtendedMoves(color, true); // Get all possible moves for the color.
    return possibleMoves.empty() && isColorInCheck(color); // Return true if no moves are possible and the color is in check.
}

// Function to simulate a move and check if it results in a check.
bool ChessBoard::TrialMove(Move move, ChessColor color) {
    Position start = move.getStart();
    Position end = move.getEnd();
    if (isTileEmpty(end)) {
        move.HavePiece()->SetPosition(end);
        grid[end.getRow()][end.getCol()].addChessPiece(move.HavePiece());
        grid[start.getRow()][start.getCol()].removeChessPiece();
        bool stillCheck = isColorInCheck(color); // Check if the move results in a check.
        grid[end.getRow()][end.getCol()].removeChessPiece();
        move.HavePiece()->SetPosition(start);
        grid[start.getRow()][start.getCol()].addChessPiece(move.HavePiece());
        return stillCheck; // Return true if the color is still in check.
    } else {
        ChessPiece* curChess = grid[end.getRow()][end.getCol()].HavePiece();
        grid[end.getRow()][end.getCol()].removeChessPiece();
        move.HavePiece()->SetPosition(end);
        grid[end.getRow()][end.getCol()].addChessPiece(move.HavePiece());
        grid[start.getRow()][start.getCol()].removeChessPiece();
        bool stillCheck = isColorInCheck(color); // Check if the move results in a check.
        grid[end.getRow()][end.getCol()].removeChessPiece();
        grid[end.getRow()][end.getCol()].addChessPiece(curChess);
        move.HavePiece()->SetPosition(start);
        grid[start.getRow()][start.getCol()].addChessPiece(move.HavePiece());
        return stillCheck; // Return true if the color is still in check.
    }
}

// Function to simulate capturing a piece and check if it can be captured back.
CapturedInfo ChessBoard::TrialCapture(Move move, ChessColor color) {
    Position start = move.getStart();
    Position end = move.getEnd();
    ChessPiece* movedPiece = move.HavePiece();

    // Store the original state
    ChessPiece* originalPieceAtEnd = grid[end.getRow()][end.getCol()].HavePiece();

    // Simulate the move
    grid[start.getRow()][start.getCol()].removeChessPiece();
    movedPiece->SetPosition(end);
    grid[end.getRow()][end.getCol()].addChessPiece(movedPiece);

    bool canBeCaptured = false;
    int scoretaken = 0;
    for (int row = 1; row <= getDimension(); ++row) {
        for (int col = 1; col <= getDimension(); ++col) {
            Position pos(row, col);
            const Tile& tile = grid[pos.getRow()][pos.getCol()];
            if (tile.isOccupied() && tile.HavePiece()->getColor() != color) {
                std::vector<ExtendedMove> opponentMoves = tile.HavePiece()->AllMoves(*this, false);
                for (const ExtendedMove& oppMove : opponentMoves) {
                    if (oppMove.getEnd() == end) {
                        canBeCaptured = true;
                        scoretaken = -tile.HavePiece()->HaveScore();
                    }
                }
            }
        }
    }

    // Undo the move
    movedPiece->SetPosition(start);
    grid[start.getRow()][start.getCol()].addChessPiece(movedPiece);
    if (originalPieceAtEnd) {
        grid[end.getRow()][end.getCol()].addChessPiece(originalPieceAtEnd);
    } else {
        grid[end.getRow()][end.getCol()].removeChessPiece();
    }

    return {canBeCaptured, scoretaken}; // Return whether the piece can be captured and the score taken.
}

// Function to get all possible moves for a specific color.
std::vector<ExtendedMove> ChessBoard::getExtendedMoves(ChessColor color, bool check) {
    std::vector<ExtendedMove> moves;
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            if (!grid[row][col].isOccupiedByColor(color)) continue;
            ChessPiece* chessPiece = grid[row][col].HavePiece();
            auto possibleMoves = chessPiece->AllMoves(*this, check);
            moves.insert(moves.end(), possibleMoves.begin(), possibleMoves.end());
        }
    }
    return moves; // Return all possible moves for the color.
}

// Function to place a piece on the board.
void ChessBoard::placePiece(const Position& pos, ChessColor color, ChessType type) {
    std::unique_ptr<ChessPiece> piece;
    switch (type) {
        case ChessType::PAWN: piece = std::make_unique<Pawn>(color, pos); break;
        case ChessType::ROOK: piece = std::make_unique<Rook>(color, pos); break;
        case ChessType::KNIGHT: piece = std::make_unique<Knight>(color, pos); break;
        case ChessType::BISHOP: piece = std::make_unique<Bishop>(color, pos); break;
        case ChessType::QUEEN: piece = std::make_unique<Queen>(color, pos); break;
        case ChessType::KING: piece = std::make_unique<King>(color, pos); break;
    }
    grid[pos.getRow()][pos.getCol()].addChessPiece(piece.get());
    pieces.push_back(std::move(piece)); // Add the piece to the list of pieces.

    displayText.notify(grid[pos.getRow()][pos.getCol()]); // Notify the text display.
    if (displayGraphical) {
        displayGraphical->notify(grid[pos.getRow()][pos.getCol()]); // Notify the graphical display if it exists.
    }
}

// Function to check if the board setup is valid.
bool ChessBoard::isSetupValid() {
    if (isColorInCheck(ChessColor::WHITE) || isColorInCheck(ChessColor::BLACK)) {
        return false; // Return false if either color is in check.
    }

    int whiteKingCount = 0;
    int blackKingCount = 0;
    for (int row = 1; row <= size; ++row) {
        for (int col = 1; col <= size; ++col) {
            if (grid[row][col].getOccupied() == false) continue;
            ChessPiece* chessPiece = grid[row][col].HavePiece();
            if (chessPiece->getType() == ChessType::KING) {
                if (chessPiece->getColor() == ChessColor::WHITE) whiteKingCount++;
                else blackKingCount++;
            }
            if (chessPiece->getType() == ChessType::PAWN && (row == 1 || row == 8)) {
                return false; // Return false if a pawn is on the first or last row.
            }
        }
    }
    return whiteKingCount == 1 && blackKingCount == 1; // Return true if there is one white king and one black king.
}

// Function to check if a position is empty.
bool ChessBoard::isTileEmpty(const Position& pos) const {
    return !grid[pos.getRow()][pos.getCol()].isOccupied(); // Return true if the position is empty.
}

// Function to check if a position is occupied by a piece of a specific color.
bool ChessBoard::isPositionOccupiedByColor(const Position& pos, const ChessColor& color) const {
    return grid[pos.getRow()][pos.getCol()].isOccupiedByColor(color); // Return true if the position is occupied by a piece of the specified color.
}

// Function to simulate an en passant move.
bool ChessBoard::simulateEnPassant(Move move, ChessColor color) {
    Position start = move.getStart();
    Position end = move.getEnd();

    ChessPiece* tobemoved = SimMovechessPiece(start, end); // Simulate moving the piece.
    grid[end.getRow()][end.getCol()].addChessPiece(tobemoved);

    grid[start.getRow()][start.getCol()].removeChessPiece();
    ChessPiece* capturedPawn = grid[start.getRow()][end.getCol()].HavePiece(); // Get the captured pawn.
    grid[start.getRow()][end.getCol()].removeChessPiece();
    bool check = isColorInCheck(color); // Check if the move results in a check.
    grid[end.getRow()][end.getCol()].removeChessPiece();
    tobemoved = SimMovechessPiece(end, start); // Undo the move.
    grid[start.getRow()][start.getCol()].addChessPiece(tobemoved);

    grid[start.getRow()][end.getCol()].addChessPiece(capturedPawn); // Restore the captured pawn.

    return check; // Return true if the color is still in check.
}
