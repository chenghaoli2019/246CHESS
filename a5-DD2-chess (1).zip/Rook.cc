#include "Rook.h"
// Constructor for the Rook class, initializes the rook piece with its color and position.
Rook::Rook(ChessColor color, Position position) :
    ChessPiece(ChessType::ROOK, color, position) {}
// Checks if the rook can move to the specified position on the board.
MoveResult Rook::CanMove(ChessBoard& board, const Move& move) {
    std::vector<ExtendedMove> PotMove = AllMoves(board, true);
    for (const auto& ExtendedMove : PotMove) {
        if (move.getStart() == ExtendedMove.getStart() && move.getEnd() == ExtendedMove.getEnd()) {
            return {true, false};
        }
    }
    return {false, false};
}
// Returns a vector of available moves for the rook piece on the board.
std::vector<ExtendedMove> Rook::AllMoves(ChessBoard& board, bool check) {
    std::vector<ExtendedMove> moves;
    const int dimension = board.getDimension();
    ChessColor opponentColor = color == ChessColor::WHITE ? ChessColor::BLACK : ChessColor::WHITE;
    int curRow = curposition.getRow();
    int curCol = curposition.getCol();

    // Add moves to the right
    for (int col = curCol + 1; col <= dimension; ++col) {
        Position newPosition{curRow, col};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (tile.isOccupiedByColor(opponentColor)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth,0,0};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth,0,0};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    // Add moves to the left
    for (int col = curCol - 1; col >= 0; --col) {
        Position newPosition{curRow, col};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (tile.isOccupiedByColor(opponentColor)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth,0,0};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth,0,0};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }
    double attackbonus;
    // Add moves upward
    if (color == ChessColor::WHITE){
        double attackbonus = 0.3;
    }
    for (int row = curRow + 1; row <= dimension; ++row) {
        Position newPosition{row, curCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (tile.isOccupiedByColor(opponentColor)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth,attackbonus,0};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth,attackbonus,0};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }
    attackbonus = 0;
    // Add moves downward
    if (color == ChessColor::BLACK){
        double attackbonus = 0.3;
    }
    for (int row = curRow - 1; row >= 0; --row) {
        Position newPosition{row, curCol};
        if (!board.isValidPos(newPosition)) break;
        const Tile& tile = board.getTileAtPos(newPosition);
        bool attackingEnemy = false;
        Move move{curposition, newPosition, this};
        bool canCheck = check && board.TrialMove(move, opponentColor);
        int selfworth = check ? board.TrialCapture(move, color).score : 0;

        if (tile.isOccupied()) {
            attackingEnemy = true;
            if (tile.isOccupiedByColor(opponentColor)) {
                ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck,
                                       tile.HavePiece()->HaveScore(), selfworth, attackbonus,0};
                if (!check || !board.TrialMove(possibleMove, color)) {
                    moves.emplace_back(possibleMove);
                }
            }
            break; // cannot move past another chess piece
        } else {
            ExtendedMove possibleMove{curposition, newPosition, this, attackingEnemy, canCheck, 0, selfworth,attackbonus,0};
            if (!check || !board.TrialMove(possibleMove, color)) {
                moves.emplace_back(possibleMove);
            }
        }
    }

    return moves;
}
